
const axios = require('axios');

function calcEMA(values, period) {
  if (!Array.isArray(values) || values.length < period) return null;
  const k = 2 / (period + 1);
  let ema = values.slice(0, period).reduce((a,b)=>a+b,0)/period;
  for (let i = period; i < values.length; i++) {
    ema = values[i] * k + ema * (1 - k);
  }
  return ema;
}

function calcRSI(values, period=14) {
  if (values.length <= period) return null;
  let gains=0, losses=0;
  for (let i=1;i<=period;i++){
    const d = values[i]-values[i-1];
    if(d>0) gains+=d; else losses+=Math.abs(d);
  }
  let avgGain=gains/period, avgLoss=losses/period;
  for (let i=period+1;i<values.length;i++){
    const d = values[i]-values[i-1];
    const gain = d>0?d:0;
    const loss = d<0?Math.abs(d):0;
    avgGain=(avgGain*(period-1)+gain)/period;
    avgLoss=(avgLoss*(period-1)+loss)/period;
  }
  if(avgLoss===0) return 100;
  const rs=avgGain/avgLoss;
  return 100 - (100/(1+rs));
}

async function fetchKlines(symbol, interval, limit){
  const url=`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const r=await axios.get(url);
  return r.data;
}

function combineWeighted(seriesArr, weights){
  const len = seriesArr[0].length;
  const out = new Array(len).fill(0);
  let wsum = weights.reduce((a,b)=>a+b,0)||1;
  for (let i=0;i<len;i++){
    let s=0;
    for (let j=0;j<seriesArr.length;j++){
      s += seriesArr[j][i]*weights[j];
    }
    out[i]=s/wsum;
  }
  return out;
}

exports.handler = async (event)=>{
  try {
    const q = event.queryStringParameters || {};
    const mode = (q.mode || "synthetic").toLowerCase();
    const interval = q.interval || "1m";
    const limit = 100;

    if(mode==="pair"){
      const symbol=(q.symbol||"BTCUSDT").toUpperCase();
      const k=await fetchKlines(symbol, interval, limit);
      const c=k.map(r=>parseFloat(r[4]));
      const ema12=calcEMA(c,12), ema26=calcEMA(c,26), rsi=calcRSI(c,14);
      const last=k[k.length-1];
      const bull = parseFloat(last[4])>parseFloat(last[1]);
      let signal="HOLD";
      if(ema12>ema26 && rsi>40 && rsi<80 && bull) signal="CALL";
      else if(ema12<ema26 && rsi>20 && rsi<60 && !bull) signal="PUT";
      return {statusCode:200, body:JSON.stringify({mode:"pair",symbol,signal,ema12,ema26,rsi,bull})};
    }

    const syms=["BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT"];
    const w=[0.55,0.25,0.12,0.08];
    const arr=[];
    for(const s of syms){
      const k=await fetchKlines(s, interval, limit);
      arr.push(k.map(r=>parseFloat(r[4])));
    }
    const combined=combineWeighted(arr,w);
    const ema12=calcEMA(combined,12), ema26=calcEMA(combined,26), rsi=calcRSI(combined,14);
    const last=combined[combined.length-1], prev=combined[combined.length-2];
    const bull = last>prev;
    let signal="HOLD";
    if(ema12>ema26 && rsi>40 && rsi<80 && bull) signal="CALL";
    else if(ema12<ema26 && rsi>20 && rsi<60 && !bull) signal="PUT";

    return {statusCode:200, body:JSON.stringify({mode:"synthetic",signal,ema12,ema26,rsi,bull})};
  } catch(e){
    return {statusCode:500, body:JSON.stringify({error:String(e)})};
  }
}
